# comments
# data types
# math
# string


# a = 12
#
# son = 123

# Reformat file
# cmd + option + L
# alt + shift + enter

# Comments
# ctrl + ?
# shift + 3

# Uzbekistan,[a] officially the Republic of Uzbekistan,
# [b] is a doubly landlocked country located in Central
# Asia. It is surrounded by five countries: Kazakhstan to
# the north, Kyrgyzstan to the northeast, Tajikistan to
# the southeast, Afghanistan to the south, and Turkmenistan
# to the southwest, making it one of only two doubly
# landlocked countries on Earth, the other being Liechtenstein.
# Uzbekistan is part of the Turkic world, as well as a member
# of the Organization of Turkic States. Uzbek, spoken by the
# Uzbek people, is the official language and spoken by the majority
# of its inhabitants, while Russian and Tajik are significant
# minority languages. Islam is the predominant religion, and most
# Uzbeks are Sunni Muslims.[15]

"""
Uzbekistan,[a] officially the Republic of Uzbekistan,
[b] is a doubly landlocked country located in Central 
Asia. It is surrounded by five countries: Kazakhstan to 
the north, Kyrgyzstan to the northeast, Tajikistan to 
the southeast, Afghanistan to the south, and Turkmenistan 
to the southwest, making it one of only two doubly 
landlocked
"""

# name = "Republic of Uzbekistan"

# print(name)

#  "O'zbekiston Buyuk Davlat"-dedi Marufjon!

# print("\"O'zbekiston Buyuk Davlat\"-dedi Marufjon!")


# a = 123
# b = "456.65"
# matn = "Salom Dunyo"
#
# natija = a + float(b)
#
# print(natija)


# a = "12"
# b = "2"
# natija = a + b
#
# print(natija)
ism = input("Ism")
familiya = input("Familiya")
viloyat = input("Viloyat")
shahar = input("Shahar")

print(f"Mening ismim {ism} familiyam {familiya}. "
      f"Men {viloyat} viloyat {shahar} shahrida istiqomat qilaman.")
