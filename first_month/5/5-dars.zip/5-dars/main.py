
# a = "Hello world"
# b = 'Hello world'
# c = '''Hello world'''
# d = """Hello world"""

# print(a, b, c, d)
# print(type(a), type(b), type(c), type(d), sep='\n')

# print(a == b == c == d)

# print(a is b is c is d)

# a = "Uzbekistan, officially the Republic of Uzbekistan, is a doubly landlocked"

# print("tan" in a)
# print("tan" not in a)
# print(a.upper())
# print(a.lower())
# print(a.strip())

# print(a.replace("U", "D"))

# print(a.split("u"))

# print(a.split())
#
# len_text = len(a)
#
# print(len_text)

# b = a[72]
# uzb = a[0:10]
# last = a[12:73]
# last = a[12:]
# first = a[:22]
# last = a[-10:]
# print(b, uzb, last, sep="\n")

# even = a[::2]
# odd = a[1::2]
# print(odd)

yil = 2023
rang = "qora"
nomi = "gentra"
pazit = 3

matn = "{0} yilda ishl\bab \bchiqarilgan \f {3}\\ angli {2}, {1}-pazitsiya!".format(yil, rang, nomi, pazit)

print(matn)





